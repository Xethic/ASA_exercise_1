import sys
import os.path

'''
The program works with the following command line:

python Schwed_Kern_assignment_exercise3.py "Pattern" input.txt

The program writes the positions into a file "output.txt"

'''

 
#preprocessing of the algorithm
#computation of shifts for each letter in sigma
def  horspool_preprocessing(sigma , P):

	shifts = dict()

	for c in sigma:
		for i in range(len(P)):
			if P[i] == c:
				shifts[c] = len(P) - i
		if c not in P:
			shifts[c] = len(P) + 1
	
	return  shifts
	
	
	
#computation of matching positions using the shifts of the preprocessing
#yields index at end of a matach
def horspool_matching(sigma, pattern, text):
	shifts = horspool_preprocessing(sigma , pattern)

	i = len(pattern) - 1

	while i < len(text):
		if text[i-len(pattern)+1:i+1] == pattern:
			yield i
		
		if i == len(text)-1:
			break	
		char = text[i+1]
	
		i += shifts[char]



#pattern as first argument, input file as second argument
#text from input.txt

if not os.path.exists(sys.argv[2]):
	print "File does not exist!"
	exit()
if len(sys.argv) > 3:
	print "Too many arguments!\nFirst argument: pattern, second argument: input file"
	exit()
	
pattern = str(sys.argv[1])

text = ""
with open(str(sys.argv[2])) as f:
	text += f.readline()

text.replace("\n", "")

#filtering sigma from the given text
#also considering the letters in the pattern and add \n as a character if it occurs in the textfile
sigma = []	

for c in pattern:
	if c not in sigma:
		sigma.append(c)
		
for c in text:
	if c not in sigma:
		sigma.append(c)
		

#outputstring
positions = ""

#function call of horspool algorithm
#writes every position into output string and adds a comma		
for position in horspool_matching(sigma, pattern, text):
	positions += str(position)
	positions += ","

#prints out the string without the last comma
#if output string is empty then the pattern was not found in the text
#writes also an output file with the positions
with open("output.txt", "w") as out:
	if positions == "":
		out.write("Text does not contain the pattern!")
	else:
		out.write(positions[:-1])
		
if positions == "":
	print "Text does not contain the pattern!"
else:
	print positions[:-1]
